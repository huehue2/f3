def negacion(p):
    z= not p
    return z

if __name__ == '__main__':
    p = [True,False]
    for (Dato) in p:
       print(Dato,negacion(Dato))

